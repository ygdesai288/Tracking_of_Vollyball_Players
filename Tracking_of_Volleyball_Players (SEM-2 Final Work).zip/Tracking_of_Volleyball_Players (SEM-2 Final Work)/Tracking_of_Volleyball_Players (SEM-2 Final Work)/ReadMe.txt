
unzip project_code file

open command promt

move to project directory

pre-requisite: python is install on your system

on command prompt run -> pip install -r requirements.txt

it may take few minutes to install all depedencies

then

run -> python ProjectStarter.py



More details:

Resources folder contains saved model
input sample folder has sample image and videaos that can be used for demo
project starter.py is main file to run the project