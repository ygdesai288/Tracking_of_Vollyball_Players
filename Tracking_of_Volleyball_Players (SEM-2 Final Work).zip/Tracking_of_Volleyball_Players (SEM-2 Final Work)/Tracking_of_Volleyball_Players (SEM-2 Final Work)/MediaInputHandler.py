import cv2
from PoseDetectorCore import BodyPoseDetector

class MediaInputHandler():

    def __init__(self):
        self.pose_detector = BodyPoseDetector()
        self.FIRST = True

    # handle image input
    def handleImage(self,img_path):

        img = cv2.imread(img_path)
        self.WEB_CAM_H,self.WEB_CAM_W = img.shape[0:2]
        img = self.pose_detector.get_pose_key_angles(img, True)
        
        cv2.imshow("Image Pose Estimation",img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        
        
    #  handle video Input         
    def handleVideo(self,video_path):
        
        cap = cv2.VideoCapture(video_path)

        while(True):
            has_frame, frame = cap.read()

            if self.FIRST:               
                # self.WEB_CAM_H,self.WEB_CAM_W = resized.shape[0:2]
                self.WEB_CAM_H,self.WEB_CAM_W = 900,600
                self.FIRST = False

            resized = cv2.resize(frame, (600,900), interpolation = cv2.INTER_AREA)
            resized = self.pose_detector.get_pose_key_angles(resized)

            cv2.imshow('frame',resized)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                

    
   

