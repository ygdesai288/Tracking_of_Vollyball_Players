import cv2
import numpy as np
import os
import math
import time


class BodyPoseDetector():

    def __init__(self):

        # Body part which we are going to track = total 18
        self.LANDMARKS = {"Nose": 0, "Neck": 1, "RShoulder": 2, "RElbow": 3, "RWrist": 4,
                           "LShoulder": 5, "LElbow": 6, "LWrist": 7, "RHip": 8, "RKnee": 9,
                           "RAnkle": 10, "LHip": 11, "LKnee": 12, "LAnkle": 13, "REye": 14,
                           "LEye": 15, "REar": 16, "LEar": 17, "Background": 18}


        self.FRAME_COUNT = 0

        # path of stored pretrained  model
        self.OPEN_POSE = '.\\resources\graph_opt.pb'

        # load model
        self.NET = cv2.dnn.readNetFromTensorflow(self.OPEN_POSE)

        self.THR = 0.1
        # image size which is compatible with model
        self.IN_WIDTH = 396
        self.IN_HEIGHT = 368

        self.POINTS = []

        # key angles: RightArm is the angle between Rshoulder, RElbow,RWrist
        # note for some calcs we can reuse the same connects!
        self.KEY_DISTANCES = {"RHand": {"RShoulder-RElbow": None, "RElbow-RWrist": None, "Neck-RShoulder": None},
                              "LHand": {"LShoulder-LElbow": None, "LElbow-LWrist": None, "Neck-LShoulder": None},
                              "RLeg":{"RHip-RKnee":None,"RKnee-RAnkle":None},
                              "LLeg":{"LHip-RKnee":None,"LKnee-RAnkle":None}}

        self.KEY_ANGLES = {"RHand": [], "LHand": [], "RLeg":[],"LLeg":[]}

        # change text colors from here
        self.TEXT_COLOR = (0, 0, 0)
        self.ANGLE_COLOR = (255, 0, 0)

        # connections from one landmark to its immediate next landmark
        self.CONNECTIONS = [["RShoulder", "RElbow"],
                            ["RElbow", "RWrist"], ["LShoulder", "LElbow"], ["LElbow", "LWrist"],
                            ["Neck", "RHip"], ["RHip", "RKnee"], ["RKnee", "RAnkle"], ["Neck", "LHip"],
                            ["LHip", "LKnee"], ["LKnee", "LAnkle"], ["Neck", "Nose"], ["Nose", "REye"],
                            ["REye", "REar"], ["Nose", "LEye"], ["LEye", "LEar"], ["LAnkle","RAnkle"], ["LWrist","RWrist"]]

    def rad_to_deg(self, rad):
        return rad * (180 / math.pi)

    # Get pose and calculate angle
    def get_pose_key_angles(self, frame, wantBlank=False):


        # for the key points that do not come in pairs
        RShoulder_pos = None
        RWrist_pos = None

        LShoulder_pos = None
        LWrist_pos = None
        
        RHip_pos = None
        RKnee_pos = None
        RAnkle_pos = None

        LHip_pos = None
        LKnee_pos = None
        LAnkle_pos = None

        frame_h, frame_w = frame.shape[0:2]

        self.NET.setInput(
            cv2.dnn.blobFromImage(frame, 1.0, (self.IN_WIDTH, self.IN_HEIGHT), (127.5, 127.5, 127.5), swapRB=True,
                                  crop=False))
        out = self.NET.forward()
        # print('ALL Landmarks:', out.shape)

        out = out[:, :19, :, :]  # MobileNet output [1, 57, -1, -1], we only need the first 19 elements
        # print('18 landmarks:', out.shape)
        # print('======================================')
        # print('=======',out[0, 2, :, :].shape)
        # print('=======',out[0, 2, :, :])

        assert (len(self.LANDMARKS) == out.shape[1])

        # clear to get new points
        self.POINTS.clear()
        
        
        prev_pos = 0
        for i in range(len(self.LANDMARKS)):
            # Slice heatmap of corresponging body's part.
            heatMap = out[0, i, :, :]

            # Originally, we try to find all the local maximums. To simplify a sample
            # we just find a global one. However only a single pose at the same time
            # could be detected this way.
            # minVal, maxVal, minLoc, maxLoc
            _, conf, _, point = cv2.minMaxLoc(heatMap)
            x = (frame_w * point[0]) / out.shape[3]  # width
            y = (frame_h * point[1]) / out.shape[2]  # Height

            # Add a point if it's confidence is higher than threshold.
            if (conf > self.THR):
                self.POINTS.append((int(x), int(y)))
            else:
                self.POINTS.append(None)
                
              
            # -------------TODO--Check Jumping-------------------------------------------------
            # if (i == 8):
             #   cv2.putText(frame, "Rknee-{:.1f}".format(int(y)), (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.TEXT_COLOR)
              #  if ((prev_pos) > int(y)):
                #   print("----jumping---")
                #   cv2.putText(frame, "Jumping..", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.TEXT_COLOR)                  
               # prev_pos = int(y)
               # print("--RKnee----- : ",int(y))
               # cv2.circle(frame, (int(x), int(y)), 10, (255,0,0), 3)
               # time.sleep(0.15)
               
          
            

        # create blank frame overlay once OpenPose has read original frame
        if wantBlank:
            frame1 = np.zeros((frame_h, frame_w, 3), np.uint8)
            self.TEXT_COLOR = (255, 255, 255)
          
        # sleep for debug purpose          
        # time.sleep(0.15)
        
        for landmark in self.CONNECTIONS:
            
            partFrom = landmark[0]
            partTo = landmark[1]
            assert (partFrom in self.LANDMARKS)
            assert (partTo in self.LANDMARKS)

            idFrom = self.LANDMARKS[partFrom]
            idTo = self.LANDMARKS[partTo]

            # if found points (if not found, returns None)
            if self.POINTS[idFrom] and self.POINTS[idTo]:

                # now we check each of the key points.
                # "a", "b" correspond to the lengths of the limbs, "c" is the length between the end dots on the triangle. See video.
                # we use law of cosines to find angle c:
                # cos(C) = (a^2 + b^2 - c^2) / 2ab
                # we first check for the points that do not come in landmarks (make up the longest side of the triangle in the vid)

                if (partFrom == "RShoulder"):
                    RShoulder_pos = self.POINTS[idFrom]

                if (partTo == "RWrist"):
                    RWrist_pos = self.POINTS[idTo]

                if (partFrom == "LShoulder"):
                    LShoulder_pos = self.POINTS[idFrom]

                if (partTo == "LWrist"):
                    LWrist_pos = self.POINTS[idTo]
                


                # START (R) Shoulder -> Elbow -> Wrist
                if (partFrom == "RShoulder" and partTo == "RElbow"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) ** 2 + (
                                self.POINTS[idFrom][1] - self.POINTS[idTo][1]) ** 2
                    self.KEY_DISTANCES["RHand"]["RShoulder-RElbow"] = dist_2             
                    

                elif (partFrom == "RElbow" and partTo == "RWrist"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) ** 2 + (
                                self.POINTS[idFrom][1] - self.POINTS[idTo][1]) ** 2
                    self.KEY_DISTANCES["RHand"]["RElbow-RWrist"] = dist_2
                # END (R) Shoulder -> Elbow -> Wrist

                # START (L) Shoulder -> Elbow -> Wrist
                elif (partFrom == "LShoulder" and partTo == "LElbow"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) ** 2 + (
                                self.POINTS[idFrom][1] - self.POINTS[idTo][1]) ** 2
                    self.KEY_DISTANCES["LHand"]["LShoulder-LElbow"] = dist_2

                elif (partFrom == "LElbow" and partTo == "LWrist"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) ** 2 + (
                                self.POINTS[idFrom][1] - self.POINTS[idTo][1]) ** 2
                    self.KEY_DISTANCES["LHand"]["LElbow-LWrist"] = dist_2
                    
                    
                # START (R) Hip -> Knee -> Ankle
                
                elif(partFrom == "RHip" and partTo == "RKnee"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) **2 + (self.POINTS[idFrom][1] - self.POINTS[idTo][1]) **2
                    self.KEY_DISTANCES["RLeg"]["RHip-RKnee"] = dist_2

                elif(partFrom == "RKnee" and partTo == "RAnkle"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) **2 + (self.POINTS[idFrom][1] - self.POINTS[idTo][1]) **2
                    self.KEY_DISTANCES["RLeg"]["RKnee-RAnkle"] = dist_2

                # END (R) Hip -> Knee -> Ankle

                # START (L) Hip -> Knee -> Ankle
                
                elif(partFrom == "LHip" and partTo == "LKnee"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) **2 + (self.POINTS[idFrom][1] - self.POINTS[idTo][1]) **2
                    self.KEY_DISTANCES["LLeg"]["LHip-LKnee"] = dist_2

                elif(partFrom == "LKnee" and partTo == "LAnkle"):
                    dist_2 = (self.POINTS[idFrom][0] - self.POINTS[idTo][0]) **2 + (self.POINTS[idFrom][1] - self.POINTS[idTo][1]) **2
                    self.KEY_DISTANCES["LLeg"]["LKnee-LAnkle"] = dist_2
                # END (L) Hip -> Knee -> Ankle
                
              
                # original image with pose and angle
                cv2.line(frame, self.POINTS[idFrom], self.POINTS[idTo], (0, 255, 0), 3)  # last value is thickness
                cv2.ellipse(frame, self.POINTS[idFrom], (3, 3), 0, 0, 360, (0, 0, 255), cv2.FILLED)
                cv2.ellipse(frame, self.POINTS[idTo], (3, 3), 0, 0, 360, (0, 0, 255), cv2.FILLED)
                
                
        
        # ------------ Print the frame number from video ------------
        print("--------------------------------------------")
        self.FRAME_COUNT = self.FRAME_COUNT + 1
        print("Frame #", self.FRAME_COUNT)
                                
                
        # ----------Calculate two leg distance in pixels-------------
        
        if (LAnkle_pos is not None and RAnkle_pos is not None):
            # print("LAnkle:",LAnkle_pos[0],"|", LAnkle_pos[1])
            # print("RAnkle:",RAnkle_pos[0],"|", RAnkle_pos[1])
            
            leg_dist=abs(LAnkle_pos[0] - RAnkle_pos[0])
            print("Result:",leg_dist)
            
            cv2.putText(frame, "Leg Distance-{:.1f}".format(leg_dist), (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            self.TEXT_COLOR)        
        # --------------------
        
        
        
        # ---------- Calculate Angles -------------
        if (RShoulder_pos is not None and RWrist_pos is not None):

            c_2 = (RShoulder_pos[0] - RWrist_pos[0]) ** 2 + (RShoulder_pos[1] - RWrist_pos[1]) ** 2

            a_2 = self.KEY_DISTANCES["RHand"]["RShoulder-RElbow"]
            b_2 = self.KEY_DISTANCES["RHand"]["RElbow-RWrist"]

            # because degrees are easily to visualize for me:
            try:
                angle = self.rad_to_deg(math.acos((a_2 + b_2 - c_2) / (2 * math.sqrt(a_2 * b_2))))

            except ZeroDivisionError:
                angle = None

            self.KEY_ANGLES["RHand"].append(angle)

            # display the angle at the center joint. Use self.LANDMARKS to find joint indices

            if (angle is not None):
                # display angle on original image
                cv2.putText(frame, "{:.1f}".format(float(angle)), self.POINTS[3], cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            self.ANGLE_COLOR)
                # display angle in legends
                cv2.putText(frame, "Right Hand Angle-{:.1f}".format(angle), (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            self.TEXT_COLOR)                
                print("Right Hand Angle-{:.1f}".format(angle))
            
            # check jumping based on hand position 
            # str1 = str(RShoulder_pos[1]) + "|" + str(RWrist_pos[1])           
            # cv2.putText(frame, str1, (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.TEXT_COLOR)            
            if (RShoulder_pos[1] > RWrist_pos[1]):   # check only y location            
                cv2.putText(frame, "Jumping...", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.TEXT_COLOR)
                print("--- Jumping ------ ")
                
                

        if (LShoulder_pos is not None and LWrist_pos is not None):

            c_2 = (LShoulder_pos[0] - LWrist_pos[0]) ** 2 + (LShoulder_pos[1] - LWrist_pos[1]) ** 2

            a_2 = self.KEY_DISTANCES["LHand"]["LShoulder-LElbow"]
            b_2 = self.KEY_DISTANCES["LHand"]["LElbow-LWrist"]

            # because degrees are easily to visualize for me:
            try:
                angle = self.rad_to_deg(math.acos((a_2 + b_2 - c_2) / (2 * math.sqrt(a_2 * b_2))))

            except ZeroDivisionError:
                angle = None

            self.KEY_ANGLES["LHand"].append(angle)



            if (angle is not None):
                # display angle on image
                cv2.putText(frame, "{:.1f}".format(angle), self.POINTS[6], cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            self.ANGLE_COLOR)
                # display angle in legends
                cv2.putText(frame, "Left Hand Angle-{:.1f}".format(angle), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            self.TEXT_COLOR)
                print("Left Hand Angle-{:.1f}".format(angle))                
        
            # check jumping based on hand position
            if (LShoulder_pos[1] > LWrist_pos[1]): # check only y location
                cv2.putText(frame, "Jumping...", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5,self.TEXT_COLOR)
                print("--- Jumping ------ ")

        # time taken to process each frame
        freq = cv2.getTickFrequency() / 1000
        t, _ = self.NET.getPerfProfile()
        cv2.putText(frame, 'Frame Process time - %.2fms' % (t / freq), (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, self.TEXT_COLOR)

        return frame





