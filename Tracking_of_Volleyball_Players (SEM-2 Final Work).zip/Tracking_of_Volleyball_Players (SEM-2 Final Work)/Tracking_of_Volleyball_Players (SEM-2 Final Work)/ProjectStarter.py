from MediaInputHandler import MediaInputHandler

class ProjectStarter:

    def imageInput(img_path, ):
        MediaInputHandler().handleImage(img_path)
        
    def videoInput(video_path):
        MediaInputHandler().handleVideo(video_path)
        
        
    

if __name__ == "__main__":
    # ProjectStarter.imageInput("./input_samples/pose5.jpg")
    ProjectStarter.videoInput("./input_samples/sample1.mp4")
 

